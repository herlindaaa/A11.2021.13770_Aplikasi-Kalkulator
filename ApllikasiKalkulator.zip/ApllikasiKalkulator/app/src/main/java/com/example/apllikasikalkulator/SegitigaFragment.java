package com.example.apllikasikalkulator;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class SegitigaFragment extends Fragment {
    private EditText txtAlas, txtTinggi;
    private Button btnHasil;
    private TextView txtLuas, txtKeliling;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_segitiga, container, false);
        txtAlas = view.findViewById(R.id.txtAlas);
        txtTinggi = view.findViewById(R.id.txtTinggi);
        btnHasil = view.findViewById(R.id.btnHasil);
        txtLuas = view.findViewById(R.id.txtLuas);
        txtKeliling = view.findViewById(R.id.txtKeliling);
        btnHasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nilai1 = txtAlas.getText().toString();
                String nilai2 = txtTinggi.getText().toString();
                if (nilai1.isEmpty()) {
                    txtAlas.setError("Data tidak boleh kosong");
                    txtAlas.requestFocus();
                } else if (nilai2.isEmpty()) {
                    txtTinggi.setError("Data tidak boleh kosong");
                    txtTinggi.requestFocus();
                } else {
                    Double alas = Double.parseDouble(nilai1);
                    Double tinggi = Double.parseDouble(nilai2);
                    Double luas = 0.5 * alas * tinggi;
                    Double keliling = alas + 2 * tinggi;
                    txtLuas.setText(String.format("%.2f", luas));
                    txtKeliling.setText(String.format("%.2f", keliling));
                }
            }
        });
        return view;
    }
}