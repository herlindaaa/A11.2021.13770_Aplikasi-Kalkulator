package com.example.apllikasikalkulator;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class PersegiFragment extends Fragment {
    private Button btnHasil;
    private EditText txtPanjang, txtLebar;
    private TextView txtLuas, txtKeliling;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_persegi, container,false);
        btnHasil = view.findViewById(R.id.btnHasil);
        txtPanjang = view.findViewById(R.id.txtPanjang);
        txtLebar = view.findViewById(R.id.txtLebar);
        txtLuas = view.findViewById(R.id.txtLuas);
        txtKeliling = view.findViewById(R.id.txtKeliling);
        btnHasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nilai1 = txtPanjang.getText().toString();
                String nilai2 = txtLebar.getText().toString();
                if(nilai1.isEmpty()){
                    txtPanjang.setError("Data tidak boleh kosong");
                    txtPanjang.requestFocus();
                } else if(nilai2.isEmpty()){
                    txtLebar.setError("Data tidak boleh kosong");
                    txtLebar.requestFocus();
                } else{
                    Integer panjang = Integer.parseInt(nilai1);
                    Integer lebar = Integer.parseInt(nilai2);
                    Integer luas = panjang*lebar;
                    Integer keliling = 2*(panjang+lebar);
                    txtLuas.setText(String.valueOf(luas));
                    txtKeliling.setText(String.valueOf(keliling));
                }
            }
        });
        return view;
    }
}